import pandas as pd
df = pd.read_csv("/Users/parsayoussefpour/Desktop/AverageSalesbyCity.csv")
df['date'] = pd.to_datetime(df['date'])
cleaned_df = df.dropna(subset=['sales', 'date', 'city'])
pivoted_df = cleaned_df.pivot_table(index='city', columns='date', values='sales',aggfunc='sum')
pivoted_df.to_csv('/Users/parsayoussefpour/Desktop/ModAverageSalesbyCity.csv')